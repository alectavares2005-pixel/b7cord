// Chatcord – cliente: chat + chamadas WebRTC (voz, vídeo, tela) em malha (mesh) com "perfect negotiation"
(() => {
"use strict";
const $ = s => document.querySelector(s);
// [largura, altura, bitrate máx. em bps]
const RES = { "360p": [640, 360, 8e5], "480p": [854, 480, 12e5], "720p": [1280, 720, 25e5], "1080p": [1920, 1080, 5e6], "1440p": [2560, 1440, 9e6], "4K": [3840, 2160, 18e6], "Nativa": [0, 0, 12e6] };
const CAM_RES = ["360p", "480p", "720p", "1080p", "1440p", "4K"];
const SCR_RES = ["Nativa", ...CAM_RES];
const COLORS = ["#5865f2", "#eb459e", "#f23f43", "#c27c0e", "#23a559", "#0b7bb5", "#9b59b6"];
const S = { ws: null, id: null, name: localStorage.getItem("cc_name") || "", servers: [], voice: {}, sv: null, ch: null, msgs: {}, ice: [{ urls: "stun:stun.l.google.com:19302" }], call: null };
const cfg = Object.assign({ camRes: "720p", camFps: "30", scrRes: "1080p", scrFps: "30", mic: "", cam: "", spk: "" }, JSON.parse(localStorage.getItem("cc_cfg") || "{}"));
const saveCfg = () => localStorage.setItem("cc_cfg", JSON.stringify(cfg));
const color = id => COLORS[[...String(id)].reduce((a, c) => a + c.charCodeAt(0), 0) % COLORS.length];
const send = o => { if (S.ws && S.ws.readyState === 1) S.ws.send(JSON.stringify(o)); };
function toast(msg) { const t = document.createElement("div"); t.className = "toast"; t.textContent = msg; document.body.append(t); setTimeout(() => t.remove(), 5000); }
function avatar(name, id, cls = "av") { const d = document.createElement("div"); d.className = cls; d.style.background = color(id); d.textContent = (name || "?")[0].toUpperCase(); return d; }
const curServer = () => S.servers.find(s => s.id === S.sv);
const curChannel = () => curServer()?.channels.find(c => c.id === S.ch);
const chanName = id => { for (const s of S.servers) for (const c of s.channels) if (c.id === id) return c.name; return ""; };

/* ================= WebSocket ================= */
function connect() {
  const ws = new WebSocket((location.protocol === "https:" ? "wss://" : "ws://") + location.host);
  S.ws = ws;
  ws.onopen = () => send({ t: "hello", name: S.name });
  ws.onmessage = e => handle(JSON.parse(e.data));
  ws.onclose = () => { if (S.call) { leaveCall(true); toast("Conexão perdida. Reconectando…"); } setTimeout(connect, 2000); };
}
function handle(m) {
  switch (m.t) {
    case "init":
      S.id = m.id; S.servers = m.servers; S.voice = m.voice; S.ice = m.ice || S.ice;
      if (!curServer()) S.sv = S.servers[0]?.id || null;
      if (!curChannel()) { const c = curServer()?.channels.find(c => c.type === "text"); S.ch = c?.id || null; }
      if (S.ch && curChannel()?.type === "text") send({ t: "history", channel: S.ch });
      renderAll(); break;
    case "servers": S.servers = m.servers; if (!curServer()) S.sv = S.servers[0]?.id || null; renderAll(); break;
    case "voice": S.voice = m.voice; renderSide(); break;
    case "history": S.msgs[m.channel] = m.msgs; if (m.channel === S.ch) renderChat(); break;
    case "msg": (S.msgs[m.channel] ||= []).push(m.msg); if (m.channel === S.ch) appendMsg(m.msg); break;
    case "voice-joined": if (S.call && S.call.channel === m.channel) { m.peers.forEach(addPeer); sendState(); renderMain(); } break;
    case "peer-joined": if (S.call) addPeer(m.peer); break;
    case "peer-left": removePeer(m.id); break;
    case "peer-state": { const p = S.call?.peers.get(m.id); if (p) { p.state = m.state || {}; refreshTiles(p); } break; }
    case "signal": onSignal(m.from, m.data); break;
  }
}

/* ================= UI: servidores, canais, chat ================= */
function renderAll() { renderRail(); renderSide(); renderMain(); }
function renderRail() {
  const r = $("#rail"); r.textContent = "";
  for (const s of S.servers) {
    const b = document.createElement("button"); b.className = "sv" + (s.id === S.sv ? " on" : ""); b.title = s.name; b.textContent = s.name.slice(0, 2).toUpperCase();
    b.onclick = () => { S.sv = s.id; const c = s.channels.find(c => c.type === "text") || s.channels[0]; selectChannel(c?.id || null); };
    r.append(b);
  }
  const a = document.createElement("button"); a.className = "sv add"; a.textContent = "+"; a.title = "Criar servidor";
  a.onclick = () => { const n = prompt("Nome do servidor:"); if (n) send({ t: "createServer", name: n }); };
  r.append(a);
}
function renderSide() {
  const s = curServer(); $("#sn").textContent = s ? s.name : "Chatcord";
  const box = $("#chs"); box.textContent = "";
  if (s) for (const type of ["text", "voice"]) {
    const l = document.createElement("div"); l.className = "lbl"; l.append(type === "text" ? "Canais de texto" : "Canais de voz");
    const add = document.createElement("button"); add.textContent = "+"; add.title = "Novo canal";
    add.onclick = () => { const n = prompt("Nome do canal:"); if (n) send({ t: "createChannel", server: s.id, name: n, type }); };
    l.append(add); box.append(l);
    for (const c of s.channels.filter(c => c.type === type)) {
      const b = document.createElement("button"); b.className = "ch" + (c.id === S.ch ? " on" : "");
      b.textContent = (type === "text" ? "# " : "🔊 ") + c.name + (S.call?.channel === c.id ? "  ●" : "");
      b.onclick = () => type === "voice" ? joinVoice(c.id) : selectChannel(c.id);
      box.append(b);
      for (const u of S.voice[c.id] || []) {
        const v = document.createElement("div"); v.className = "vm"; v.append(avatar(u.name, u.id), u.name + (u.state?.screenId ? " 🖥️" : u.state?.cam ? " 📷" : "") + (u.state?.deaf ? " 🔇" : u.state?.muted ? " 🎙️✖" : ""));
        box.append(v);
      }
    }
  }
  const me = $("#me"); me.textContent = ""; me.append(avatar(S.name, S.id || S.name));
  const n = document.createElement("div"); n.textContent = S.name; me.append(n);
  const g = document.createElement("button"); g.textContent = "⚙️"; g.title = "Configurações"; g.onclick = openSettings; me.append(g);
}
function selectChannel(id) {
  S.ch = id; const c = curChannel();
  if (c?.type === "text" && !S.msgs[id]) send({ t: "history", channel: id });
  renderSide(); renderMain();
}
function renderMain() {
  const c = curChannel();
  const inCall = !!(S.call && c && c.type === "voice" && S.call.channel === c.id);
  const showChat = !!c && c.type === "text";
  $("#chat").hidden = !showChat; $("#call").hidden = !inCall; $("#empty").hidden = showChat || inCall;
  $("#callbar").hidden = !S.call;
  $("#top").textContent = c ? (c.type === "text" ? "# " : "🔊 ") + c.name : "";
  if (showChat) { $("#inp").placeholder = "Conversar em #" + c.name; renderChat(); }
  updateBar();
}
function msgEl(m) {
  const d = document.createElement("div"); d.className = "m"; d.append(avatar(m.name, m.uid));
  const c = document.createElement("div"); const b = document.createElement("b"); b.textContent = m.name;
  const t = document.createElement("small"); t.textContent = new Date(m.ts).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
  const p = document.createElement("p"); p.textContent = m.text; c.append(b, t, p); d.append(c); return d;
}
function renderChat() { const box = $("#msgs"); box.textContent = ""; (S.msgs[S.ch] || []).forEach(m => box.append(msgEl(m))); box.scrollTop = box.scrollHeight; }
function appendMsg(m) { const box = $("#msgs"); const end = box.scrollHeight - box.scrollTop - box.clientHeight < 100; box.append(msgEl(m)); if (end) box.scrollTop = box.scrollHeight; }
$("#chatForm").onsubmit = e => { e.preventDefault(); const v = $("#inp").value.trim(); if (!v || !S.ch) return; send({ t: "msg", channel: S.ch, text: v }); $("#inp").value = ""; };

/* ================= Chamadas ================= */
const audioC = () => ({ deviceId: cfg.mic ? { exact: cfg.mic } : undefined, echoCancellation: true, noiseSuppression: true, autoGainControl: true });
function vidC(res, fps, dev) {
  const [w, h] = RES[res]; const v = { frameRate: { ideal: +fps } };
  if (w) { v.width = { ideal: w }; v.height = { ideal: h }; }
  if (dev) v.deviceId = { exact: dev };
  return v;
}
function sendState() {
  const c = S.call; if (!c) return;
  send({ t: "state", state: { muted: c.state.muted, deaf: c.state.deaf, cam: c.state.cam, screenId: c.state.screenId, mainId: c.main.id } });
}
async function joinVoice(chId) {
  if (S.call?.channel === chId) { S.ch = chId; renderSide(); renderMain(); return; }
  if (S.call) leaveCall();
  S.ch = chId;
  const call = S.call = { channel: chId, peers: new Map(), tiles: new Map(), main: new MediaStream(), mic: null, cam: null, screen: null, state: { muted: false, deaf: false, cam: false, screenId: null } };
  if (!navigator.mediaDevices?.getUserMedia) toast("Câmera/microfone exigem HTTPS (ou localhost).");
  else try {
    const ms = await navigator.mediaDevices.getUserMedia({ audio: audioC() });
    call.mic = ms.getAudioTracks()[0]; call.main.addTrack(call.mic);
  } catch (e) { toast("Sem microfone (" + e.name + "). Entrando como ouvinte."); call.state.muted = true; }
  if (S.call !== call) { call.mic?.stop(); return; }
  setTile("me", { stream: call.main, label: S.name + " (você)", video: false, self: true, id: S.id });
  if (call.mic) watch("me", new MediaStream([call.mic]));
  send({ t: "joinVoice", channel: chId });
  renderSide(); renderMain();
}
function leaveCall(silent) {
  const c = S.call; if (!c) return;
  S.call = null;
  for (const p of c.peers.values()) p.pc.close();
  [c.mic, c.cam, c.screen && c.screen.getTracks()].flat().filter(Boolean).forEach(t => t.stop());
  speak.clear(); $("#grid").textContent = "";
  if (!silent) send({ t: "leaveVoice" });
  if (curChannel()?.type === "voice") { S.ch = curServer()?.channels.find(x => x.type === "text")?.id || null; if (S.ch && !S.msgs[S.ch]) send({ t: "history", channel: S.ch }); }
  renderSide(); renderMain();
}

/* ---- Peers / perfect negotiation ---- */
function addPeer(info) {
  const c = S.call; if (!c || c.peers.has(info.id)) return;
  const pc = new RTCPeerConnection({ iceServers: S.ice });
  const p = { id: info.id, name: info.name, state: info.state || {}, pc, polite: S.id > info.id, making: false, ignore: false, streams: new Map(), senders: {} };
  c.peers.set(info.id, p);
  pc.onnegotiationneeded = async () => {
    try { p.making = true; await pc.setLocalDescription(); send({ t: "signal", to: p.id, data: { description: pc.localDescription } }); }
    catch (e) { console.error(e); } finally { p.making = false; }
  };
  pc.onicecandidate = e => { if (e.candidate) send({ t: "signal", to: p.id, data: { candidate: e.candidate } }); };
  pc.oniceconnectionstatechange = () => { if (pc.iceConnectionState === "failed") pc.restartIce(); };
  pc.ontrack = e => {
    const s = e.streams[0]; if (!s) return;
    p.streams.set(s.id, s); s.onremovetrack = () => refreshTiles(p); refreshTiles(p);
  };
  if (c.mic) p.senders.mic = pc.addTrack(c.mic, c.main);
  if (c.cam) addSender(p, "cam", c.cam, c.main);
  if (c.screen) c.screen.getTracks().forEach(t => addSender(p, t.kind === "video" ? "scr" : "scrA", t, c.screen));
  setTile(p.id, { stream: null, label: p.name, video: false, id: p.id });
  renderSide();
}
function removePeer(id) {
  const c = S.call; const p = c?.peers.get(id); if (!p) return;
  p.pc.close(); c.peers.delete(id);
  for (const k of [id, id + ":screen"]) { c.tiles.get(k)?.el.remove(); c.tiles.delete(k); speak.delete(k); }
}
async function onSignal(from, data) {
  const p = S.call?.peers.get(from); if (!p) return; const pc = p.pc;
  try {
    if (data.description) {
      const collision = data.description.type === "offer" && (p.making || pc.signalingState !== "stable");
      p.ignore = !p.polite && collision; if (p.ignore) return;
      await pc.setRemoteDescription(data.description);
      if (data.description.type === "offer") { await pc.setLocalDescription(); send({ t: "signal", to: from, data: { description: pc.localDescription } }); }
    } else if (data.candidate) {
      try { await pc.addIceCandidate(data.candidate); } catch (e) { if (!p.ignore) throw e; }
    }
  } catch (e) { console.error("signal", e); }
}
function addSender(p, key, track, stream) { p.senders[key] = p.pc.addTrack(track, stream); tune(p.senders[key], key); }
function dropSender(p, key) { const s = p.senders[key]; if (s) { try { p.pc.removeTrack(s); } catch {} delete p.senders[key]; } }
// limita bitrate/fps conforme a resolução escolhida
function tune(sender, key) {
  if (!sender || sender.track?.kind !== "video") return;
  const isCam = key === "cam"; const br = RES[isCam ? cfg.camRes : cfg.scrRes][2]; const fps = +(isCam ? cfg.camFps : cfg.scrFps);
  const apply = () => { try {
    const prm = sender.getParameters(); if (!prm.encodings?.length) prm.encodings = [{}];
    prm.encodings[0].maxBitrate = br; prm.encodings[0].maxFramerate = fps;
    prm.degradationPreference = isCam ? "balanced" : "maintain-resolution";
    sender.setParameters(prm).catch(() => {});
  } catch {} };
  setTimeout(apply, 400); setTimeout(apply, 3000);
}

/* ---- Tiles ---- */
function ensureTile(key) {
  const c = S.call; let t = c.tiles.get(key); if (t) return t;
  const el = document.createElement("div"); el.className = "tile novideo";
  const v = document.createElement("video"); v.autoplay = true; v.playsInline = true;
  const av = document.createElement("div"); av.className = "avatar";
  const lb = document.createElement("div"); lb.className = "label";
  const bd = document.createElement("div"); bd.className = "badge";
  el.append(v, av, lb, bd);
  el.onclick = () => el.classList.toggle("pin"); el.ondblclick = () => el.requestFullscreen?.();
  $("#grid").append(el); t = { el, v, av, lb, bd }; c.tiles.set(key, t); return t;
}
function setTile(key, o) {
  const t = ensureTile(key);
  if (o.stream !== undefined && t.v.srcObject !== o.stream) t.v.srcObject = o.stream;
  t.v.muted = !!o.self || S.call.state.deaf;
  if (cfg.spk && t.v.setSinkId) t.v.setSinkId(cfg.spk).catch(() => {});
  t.el.classList.toggle("novideo", !o.video);
  t.lb.textContent = o.label; t.av.textContent = (o.label || "?")[0].toUpperCase(); t.av.style.background = color(o.id || key);
  t.bd.textContent = o.badge || "";
  if (o.stream) t.v.play?.().catch(() => {});
}
function refreshTiles(p) {
  const c = S.call; if (!c || !c.peers.has(p.id)) return;
  const badge = (p.state.deaf ? "🔇" : p.state.muted ? "🎙️✖" : "");
  let mainStream = null, screenStream = null;
  for (const [id, s] of p.streams) {
    if (id === p.state.screenId) screenStream = s; else if (!p.state.mainId || id === p.state.mainId) mainStream = s;
  }
  setTile(p.id, { stream: mainStream, label: p.name, video: !!p.state.cam && !!mainStream, id: p.id, badge });
  if (mainStream) watch(p.id, mainStream);
  if (screenStream) { setTile(p.id + ":screen", { stream: screenStream, label: p.name + " — tela", video: true, id: p.id }); watch(p.id + ":screen", screenStream); }
  else if (c.tiles.has(p.id + ":screen")) { c.tiles.get(p.id + ":screen").el.remove(); c.tiles.delete(p.id + ":screen"); speak.delete(p.id + ":screen"); }
  for (const [id, st] of [...p.streams]) if (st.getTracks().every(t => t.readyState === "ended")) p.streams.delete(id);
  renderSide();
}

/* ---- Indicador de fala ---- */
const speak = new Map(); let actx;
function watch(key, stream) {
  if (speak.has(key) || !stream.getAudioTracks().length) return;
  try {
    actx ||= new AudioContext(); if (actx.state === "suspended") actx.resume();
    const an = actx.createAnalyser(); an.fftSize = 512; actx.createMediaStreamSource(stream).connect(an);
    speak.set(key, { an, buf: new Uint8Array(an.fftSize) });
  } catch {}
}
setInterval(() => {
  for (const [k, s] of speak) {
    const t = S.call?.tiles.get(k); if (!t) { speak.delete(k); continue; }
    s.an.getByteTimeDomainData(s.buf); let m = 0; for (const x of s.buf) m = Math.max(m, Math.abs(x - 128));
    t.el.classList.toggle("speaking", m > 12 && !(k === "me" && S.call.state.muted));
  }
}, 150);

/* ---- Controles ---- */
function updateBar() {
  const c = S.call; if (!c) return;
  $("#bMic").classList.toggle("off", c.state.muted); $("#bDeaf").classList.toggle("off", c.state.deaf);
  $("#bCam").classList.toggle("on", c.state.cam); $("#bScr").classList.toggle("on", !!c.state.screenId);
  setTile("me", { stream: undefined, label: S.name + " (você)", video: c.state.cam, self: true, id: S.id, badge: c.state.deaf ? "🔇" : c.state.muted ? "🎙️✖" : "" });
}
function applyDeaf() { const c = S.call; for (const [k, t] of c.tiles) t.v.muted = k === "me" || k === "me:screen" || c.state.deaf; }
$("#bMic").onclick = () => { const c = S.call; if (!c) return; if (!c.mic) return toast("Nenhum microfone disponível."); c.state.muted = !c.state.muted; if (c.state.deaf && !c.state.muted) { c.state.deaf = false; applyDeaf(); } c.mic.enabled = !c.state.muted; sendState(); updateBar(); };
$("#bDeaf").onclick = () => { const c = S.call; if (!c) return; c.state.deaf = !c.state.deaf; if (c.state.deaf) { c.state.muted = true; if (c.mic) c.mic.enabled = false; } applyDeaf(); sendState(); updateBar(); };
$("#bLeave").onclick = () => leaveCall();
$("#bSet").onclick = openSettings;

$("#bCam").onclick = async () => {
  const c = S.call; if (!c) return;
  if (c.cam) { // desligar
    for (const p of c.peers.values()) dropSender(p, "cam");
    c.main.removeTrack(c.cam); c.cam.stop(); c.cam = null; c.state.cam = false; sendState(); return updateBar();
  }
  try {
    const ms = await navigator.mediaDevices.getUserMedia({ video: vidC(cfg.camRes, cfg.camFps, cfg.cam) });
    c.cam = ms.getVideoTracks()[0]; c.cam.contentHint = "motion"; c.main.addTrack(c.cam);
    c.cam.onended = () => { if (S.call?.cam === c.cam) $("#bCam").onclick(); };
    c.state.cam = true; sendState();
    for (const p of c.peers.values()) addSender(p, "cam", c.cam, c.main);
    const tl = c.tiles.get("me"); tl.v.srcObject = c.main; updateBar();
  } catch (e) { toast("Não foi possível abrir a câmera: " + e.name); }
};
$("#bScr").onclick = async () => {
  const c = S.call; if (!c) return;
  if (c.screen) return stopScreen();
  if (!navigator.mediaDevices?.getDisplayMedia) return toast("Seu navegador não suporta compartilhamento de tela.");
  try {
    const ms = await navigator.mediaDevices.getDisplayMedia({ video: vidC(cfg.scrRes, cfg.scrFps), audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false } });
    c.screen = ms; const v = ms.getVideoTracks()[0]; v.contentHint = "detail"; v.onended = stopScreen;
    c.state.screenId = ms.id; sendState(); // avisa o id ANTES de enviar as trilhas
    for (const p of c.peers.values()) ms.getTracks().forEach(t => addSender(p, t.kind === "video" ? "scr" : "scrA", t, ms));
    setTile("me:screen", { stream: ms, label: "Sua tela", video: true, self: true, id: S.id });
    updateBar(); renderSide();
  } catch (e) { if (e.name !== "NotAllowedError") toast("Falha ao compartilhar tela: " + e.name); }
};
function stopScreen() {
  const c = S.call; if (!c || !c.screen) return;
  for (const p of c.peers.values()) { dropSender(p, "scr"); dropSender(p, "scrA"); }
  c.screen.getTracks().forEach(t => { t.onended = null; t.stop(); }); c.screen = null; c.state.screenId = null;
  c.tiles.get("me:screen")?.el.remove(); c.tiles.delete("me:screen"); sendState(); updateBar();
}

/* ---- Configurações ---- */
async function openSettings() {
  const fill = (el, items, val) => { el.textContent = ""; items.forEach(([v, l]) => { const o = document.createElement("option"); o.value = v; o.textContent = l; el.append(o); }); el.value = val; };
  let devs = [];
  try { devs = await navigator.mediaDevices.enumerateDevices(); } catch {}
  const list = kind => [["", "Padrão"], ...devs.filter(d => d.kind === kind && d.deviceId).map(d => [d.deviceId, d.label || kind])];
  fill($("#sMic"), list("audioinput"), cfg.mic); fill($("#sCam"), list("videoinput"), cfg.cam); fill($("#sSpk"), list("audiooutput"), cfg.spk);
  fill($("#sCamRes"), CAM_RES.map(r => [r, r]), cfg.camRes); fill($("#sScrRes"), SCR_RES.map(r => [r, r]), cfg.scrRes);
  $("#sCamFps").value = cfg.camFps; $("#sScrFps").value = cfg.scrFps;
  $("#settings").showModal();
}
$("#sSave").onclick = () => {
  const old = { ...cfg };
  Object.assign(cfg, { mic: $("#sMic").value, cam: $("#sCam").value, spk: $("#sSpk").value, camRes: $("#sCamRes").value, camFps: $("#sCamFps").value, scrRes: $("#sScrRes").value, scrFps: $("#sScrFps").value });
  saveCfg(); if (S.call) applySettings(old);
};
async function swapTrack(kind, track, key, stream) { // troca a trilha ao vivo sem renegociar
  const c = S.call;
  for (const p of c.peers.values()) await p.senders[key]?.replaceTrack(track).catch(() => {});
  return track;
}
async function applySettings(old) {
  const c = S.call;
  try {
    if (c.mic && cfg.mic !== old.mic) {
      const n = (await navigator.mediaDevices.getUserMedia({ audio: audioC() })).getAudioTracks()[0]; n.enabled = !c.state.muted;
      await swapTrack("audio", n, "mic"); c.main.removeTrack(c.mic); c.mic.stop(); c.mic = n; c.main.addTrack(n);
      speak.delete("me"); watch("me", new MediaStream([n]));
    }
    if (c.cam && (cfg.cam !== old.cam || cfg.camRes !== old.camRes || cfg.camFps !== old.camFps)) {
      const n = (await navigator.mediaDevices.getUserMedia({ video: vidC(cfg.camRes, cfg.camFps, cfg.cam) })).getVideoTracks()[0]; n.contentHint = "motion";
      await swapTrack("video", n, "cam"); c.main.removeTrack(c.cam); c.cam.onended = null; c.cam.stop(); c.cam = n; c.main.addTrack(n);
      n.onended = () => { if (S.call?.cam === n) $("#bCam").onclick(); };
      for (const p of c.peers.values()) tune(p.senders.cam, "cam");
    }
    if (c.screen && (cfg.scrRes !== old.scrRes || cfg.scrFps !== old.scrFps)) {
      await c.screen.getVideoTracks()[0].applyConstraints(vidC(cfg.scrRes, cfg.scrFps)).catch(() => toast("A fonte não aceitou essa resolução."));
      for (const p of c.peers.values()) tune(p.senders.scr, "scr");
    }
    for (const t of c.tiles.values()) if (cfg.spk && t.v.setSinkId) t.v.setSinkId(cfg.spk).catch(() => {});
  } catch (e) { toast("Erro ao aplicar configurações: " + e.name); }
}

/* ================= Início ================= */
$("#loginForm").onsubmit = e => { e.preventDefault(); S.name = $("#nameInput").value.trim().slice(0, 24); if (!S.name) return; localStorage.setItem("cc_name", S.name); $("#login").hidden = true; connect(); };
window.addEventListener("beforeunload", () => { if (S.call) send({ t: "leaveVoice" }); });
if (S.name) connect(); else $("#login").hidden = false;
})();
